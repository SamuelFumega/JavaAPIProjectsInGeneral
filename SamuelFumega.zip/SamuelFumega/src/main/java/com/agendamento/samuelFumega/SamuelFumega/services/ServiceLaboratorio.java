package com.agendamento.samuelFumega.SamuelFumega.services;

import com.agendamento.samuelFumega.SamuelFumega.models.Laboratorio;
import com.agendamento.samuelFumega.SamuelFumega.repositories.RepositoryLaboratorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServiceLaboratorio {
    @Autowired
    private RepositoryLaboratorio repositoryLaboratorio;
    public void saveLab(Laboratorio laboratorio){ // SALVAR LAB
        System.out.println("foi o método PSOT, CAÇAMBA");
        repositoryLaboratorio.save(laboratorio);
    }
    public List<Laboratorio> listAll(){ // LISTAR LABS
        System.out.println("foi o método LIST, CAÇAMBA");
        return repositoryLaboratorio.findAll();
    }
    public Optional<Laboratorio> getLab(int id){ // PEGAR LABORATORIO DISTINTO PELO ID
        System.out.println("foi o método GET, CAÇAMBA");
        return repositoryLaboratorio.findById(id);
    }
    public void deleteLab(Laboratorio laboratorio){ // DELETAR LABORATORIO DISTINTO PELO ID
        System.out.println("foi o método DELETE, CAÇAMBA");
        repositoryLaboratorio.delete(laboratorio);
    }
}

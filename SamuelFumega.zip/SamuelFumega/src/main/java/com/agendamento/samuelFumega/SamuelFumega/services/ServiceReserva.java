package com.agendamento.samuelFumega.SamuelFumega.services;


import com.agendamento.samuelFumega.SamuelFumega.models.Reserva;

import com.agendamento.samuelFumega.SamuelFumega.repositories.RepositoryReserva;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServiceReserva {
    @Autowired
    private RepositoryReserva repositoryReserva;
    public void saveRes(Reserva reserva){ // SALVAR RESERVA
        System.out.println("foi o método POST, CAÇAMBA");
        repositoryReserva.save(reserva);
    }
    public List<Reserva> listAll(){ // LISTAR RESERVA
        System.out.println("foi o método LIST, CAÇAMBA");
        return repositoryReserva.findAll();
    }
    public Optional<Reserva> getLab(int id){ // PEGAR RESERVA DISTINTA PELO ID
        System.out.println("foi o método GET, CAÇAMBA");
        return repositoryReserva.findById(id);
    }
    public void deleteRes(Reserva reserva){ // DELETAR RESERVA DISTINTA PELO ID
        System.out.println("foi o método DELETE, CAÇAMBA");
        repositoryReserva.delete(reserva);
    }
}

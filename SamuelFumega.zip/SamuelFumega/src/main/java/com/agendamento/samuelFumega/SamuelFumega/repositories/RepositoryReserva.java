package com.agendamento.samuelFumega.SamuelFumega.repositories;

import com.agendamento.samuelFumega.SamuelFumega.models.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryReserva extends JpaRepository<Reserva,Integer> {
}

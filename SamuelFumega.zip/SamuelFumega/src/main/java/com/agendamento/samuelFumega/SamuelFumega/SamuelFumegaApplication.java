package com.agendamento.samuelFumega.SamuelFumega;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SamuelFumegaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SamuelFumegaApplication.class, args);
	}

}

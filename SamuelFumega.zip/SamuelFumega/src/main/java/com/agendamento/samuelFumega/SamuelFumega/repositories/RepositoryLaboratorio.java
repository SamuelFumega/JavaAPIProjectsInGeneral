package com.agendamento.samuelFumega.SamuelFumega.repositories;

import com.agendamento.samuelFumega.SamuelFumega.models.Laboratorio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryLaboratorio extends JpaRepository<Laboratorio,Integer> {
}

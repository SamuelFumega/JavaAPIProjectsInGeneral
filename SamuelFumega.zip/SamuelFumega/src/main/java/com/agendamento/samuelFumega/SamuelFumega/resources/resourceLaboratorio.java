package com.agendamento.samuelFumega.SamuelFumega.resources;


import com.agendamento.samuelFumega.SamuelFumega.models.Laboratorio;
import com.agendamento.samuelFumega.SamuelFumega.services.ServiceLaboratorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/laboratorios")
public class resourceLaboratorio {

            @Autowired
            private ServiceLaboratorio serviceLaboratorio;

    @GetMapping("")
    public ResponseEntity<List<Laboratorio>> listAll (){

        return new ResponseEntity<List<Laboratorio>>(serviceLaboratorio.listAll(), HttpStatus.OK);

    }
    @GetMapping("/{codigo}")
    public ResponseEntity<Laboratorio> getLaboratorio(@PathVariable("codigo") int id){

        Optional <Laboratorio> mensagemOptional = serviceLaboratorio.getLab(id);

        if (mensagemOptional.isPresent()) {
            return new ResponseEntity<Laboratorio>(mensagemOptional.get(), HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping("/salvar")
    public ResponseEntity<Laboratorio> saveLab(@RequestBody Laboratorio laboratorio){
        serviceLaboratorio.saveLab(laboratorio);
        return new ResponseEntity<Laboratorio>(laboratorio, HttpStatus.CREATED);
    }
    @DeleteMapping("/excluir/{codigo}")
    public ResponseEntity<Laboratorio> delLaboratorio(@PathVariable("codigo") int codigo){
        Optional<Laboratorio> optionalMensagem = serviceLaboratorio.getLab(codigo);
        if (optionalMensagem.isPresent()) {

            serviceLaboratorio.deleteLab(optionalMensagem.get());
            return new ResponseEntity<>(null,HttpStatus.OK);

        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    @PostMapping("/editar/{codigo}")
    public ResponseEntity<Laboratorio> upLab(@PathVariable("codigo") int codigo, @RequestBody Laboratorio laboratorio){
        Optional<Laboratorio> optionalMensagem = serviceLaboratorio.getLab(codigo);

        if (optionalMensagem.isPresent()) {
            laboratorio.setId(codigo);
            serviceLaboratorio.saveLab(optionalMensagem.get());
            return new ResponseEntity<>(null,HttpStatus.OK);
        }

        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}

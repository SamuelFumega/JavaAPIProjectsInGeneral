package com.agendamento.samuelFumega.SamuelFumega.resources;


import com.agendamento.samuelFumega.SamuelFumega.models.Reserva;
import com.agendamento.samuelFumega.SamuelFumega.services.ServiceReserva;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/reservas")
public class resourceReserva {

    @Autowired
    private ServiceReserva serviceReserva;

    @GetMapping("")
    public ResponseEntity<List<Reserva>> listAll (){

        return new ResponseEntity<List<Reserva>>(serviceReserva.listAll(), HttpStatus.OK);

    }
    @GetMapping("/{codigo}")
    public ResponseEntity<Reserva> getRes(@PathVariable("codigo") int id){

        Optional<Reserva> mensagemOptional = serviceReserva.getLab(id);

        if (mensagemOptional.isPresent()) {
            return new ResponseEntity<Reserva>(mensagemOptional.get(), HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PostMapping("/salvar")
    public ResponseEntity<Reserva> saveRes(@RequestBody Reserva reserva){
        serviceReserva.saveRes(reserva);
        return new ResponseEntity<Reserva>(reserva, HttpStatus.CREATED);
    }
    @DeleteMapping("/excluir/{codigo}")
    public ResponseEntity<Reserva> delReserva(@PathVariable("codigo") int codigo){
        Optional<Reserva> optionalMensagem = serviceReserva.getLab(codigo);
        if (optionalMensagem.isPresent()) {

            serviceReserva.deleteRes(optionalMensagem.get());
            return new ResponseEntity<>(null,HttpStatus.OK);

        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    @PostMapping("/editar/{codigo}")
    public ResponseEntity<Reserva> upLab(@PathVariable("codigo") int codigo, @RequestBody Reserva reserva){
        Optional<Reserva> optionalMensagem = serviceReserva.getLab(codigo);

        if (optionalMensagem.isPresent()) {
            reserva.setId(codigo);
            serviceReserva.saveRes(optionalMensagem.get());
            return new ResponseEntity<>(null,HttpStatus.OK);
        }

        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}

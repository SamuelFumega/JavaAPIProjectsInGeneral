package com.agendamento.samuelFumega.SamuelFumega;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamuelFumegaApplicationTests {

	@Test
	void contextLoads() {
	}

}
